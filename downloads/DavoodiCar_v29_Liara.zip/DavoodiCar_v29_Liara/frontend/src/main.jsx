import React,{useEffect,useRef,useState} from 'react';
import{createRoot}from'react-dom/client';
import{CarFront,Search,LockKeyhole,LogOut,ExternalLink,LoaderCircle,ShieldCheck,ArrowLeft,TrendingUp,TrendingDown,ChartNoAxesCombined,ArrowUpLeft,CheckCircle2,Sparkles,Clock3,Info,Eye,EyeOff,RotateCcw,Mic,MicOff,AudioLines,Car,Check,ImageOff,Gauge,History,Share2,Calculator,GitCompareArrows,SlidersHorizontal,Download,RefreshCw}from'lucide-react';
import './style.css';
import QuickVerdict from './QuickVerdict.jsx';
import davoudiLogo from './assets/davoudi-cars-logo.jpg';
const BODY_PARTS=['کاپوت','صندوق عقب','درب جلو راننده','درب عقب راننده','درب جلو شاگرد','درب عقب شاگرد','گلگیر جلو راننده','گلگیر عقب راننده','گلگیر جلو شاگرد','گلگیر عقب شاگرد','سقف'];
const TRIM_CHOICES={'۲۰۶':['تیپ ۲','تیپ ۳','تیپ ۵','تیپ ۶'],'۲۰۷':['دنده‌ای','اتوماتیک','پانوراما','مولتی کالر'],'سانتافه':['۲۴۰۰ سی‌سی','۳۳۰۰ سی‌سی','MPI','GDI'],'فیدلیتی':['پرایم','پرستیژ','الیت','ایکس ۳']};
const COLORS=['سفید','مشکی','قرمز','نقره‌ای','نوک مدادی','آبی','خاکستری','بژ','قهوه‌ای','سبز','طلایی','آلبالویی','سایر'];
const fmt=n=>typeof n==='number'&&Number.isFinite(n)?new Intl.NumberFormat('fa-IR').format(n)+' تومان':'داده کافی نیست';
const shortMoney=n=>typeof n==='number'&&Number.isFinite(n)?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:2}).format(n/1000000000)+' میلیارد تومان':'—';
const priceHeadline=s=>s?.price_average?fmt(s.price_average):(s?.limited_evidence?`شواهد محدود (${s.sample_count||0} نمونه)`:'داده کافی نیست');
async function safeJson(response){const contentType=response.headers.get('content-type')||'';if(!contentType.includes('application/json'))throw new Error('API پاسخ JSON نداد (HTTP '+response.status+'). احتمالاً نسخه فرانت و بک‌اند یکسان نیست یا مسیر API به صفحه HTML هدایت شده است.');return response.json()}
function localVoiceParse(text){
  // Offline fallback only: all high-confidence fields must come from the text.
  const t=String(text||'').replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
  const models=[[/فیدلیتی|فیدیلیتی|فیدیلتی|فیتیلی|fideli(?:ty|ti)/i,'بهمن موتور','فیدلیتی'],[/تیگو\s*(?:۷|7|هفت)\s*پرو\s*مکس|tiggo\s*7\s*pro\s*max/i,'چری','تیگو ۷ پرو مکس'],[/تیگو\s*(?:۷|7|هفت)\s*پرو|tiggo\s*7\s*pro/i,'چری','تیگو ۷ پرو'],[/تیگو\s*(?:۷|7|هفت)|tiggo\s*[- ]?7/i,'چری','تیگو ۷'],[/تیگو\s*(?:۸|8|هشت)\s*پرو|tiggo\s*8\s*pro/i,'چری','تیگو ۸ پرو'],[/تیگو\s*(?:۸|8|هشت)|tiggo\s*[- ]?8/i,'چری','تیگو ۸'],[/سانتافه|سانتافایه|سانتا\s*فه|santa\s*fe/i,'هیوندای','سانتافه'],[/توسان|tucson/i,'هیوندای','توسان'],[/(?:پژو\s*)?(?:\b207\b|دویست\s*و\s*هفت|دو\s*صفر\s*هفت)/i,'پژو','۲۰۷'],[/(?:پژو\s*)?(?:\b206\b|دویست\s*و\s*شش|دو\s*صفر\s*شش)/i,'پژو','۲۰۶'],[/دنا\s*پلاس/i,'ایران خودرو','دنا پلاس'],[/کمری|camry/i,'تویوتا','کمری'],[/سراتو/i,'کیا','سراتو'],[/آئودی.*(?:a\s*3\s*l|ای سه ال)|a\s*3\s*l/i,'آئودی','A3L'],[/آئودی.*(?:a\s*3|ای سه)|a\s*3/i,'آئودی','A3'],[/تارا/i,'ایران خودرو','تارا'],[/شاهین/i,'سایپا','شاهین']]
  const found=models.find(x=>x[0].test(t));
  let year=null;
  const yearRegex=/(?<!\d)(13\d{2}|14\d{2}|19\d{2}|20\d{2})(?!\d)/g;
  for(const match of t.matchAll(yearRegex)){
    const y=Number(match[1]);
    if(!((y>=1350&&y<=1450)||(y>=1950&&y<=2035)))continue;
    const before=t.slice(Math.max(0,match.index-25),match.index);
    // 'کارکرد ۲۰۲۵ کیلومتر' is mileage, not year.
    if(/(?:کارکرد|کیلومتر|رفته)\s*[:\-]?\s*$/.test(before))continue;
    year=y;break;
  }
  const isNew=/(?:^|\s)(?:نو|صفر(?:\s*کیلومتر)?|آکبند|اکبند|خشک)(?=\s|$|[،,.])/.test(t);
  let mileage=isNew?0:null;
  if(!isNew){
    const mileageMatches=[
      t.match(/(?:کارکرد|کار\s*کرده|رفته)\s*[:\-]?\s*(\d[\d,]*)\s*(هزار|کیلومتر|km)?/i),
      t.match(/(?<!\d)(\d[\d,]*)\s*(هزار)?\s*(?:کیلومتر|km)/i),
      t.match(/(?<!\d)(\d[\d,]*)\s*هزار\s*(?:تا|کارکرد|رفته)/i),
    ].filter(Boolean);
    const candidate=mileageMatches[0];
    if(candidate){
      const n=Number(candidate[1].replace(/,/g,''));
      const amount=n*(/هزار/.test(candidate[0])?1000:1);
      if(amount>=0&&amount<=2000000)mileage=amount;
    }
  }
  const color=/آ\s*لبالو(?:یی|ی)?|البالو(?:یی|ی)?/.test(t)?'آلبالویی':['نوک مدادی','نقره‌ای','سفید','مشکی','قرمز','آبی','خاکستری','بژ','قهوه‌ای','سبز','طلایی'].find(c=>t.includes(c))||null;
  const trim=found?.[2]==='فیدلیتی'?(t.match(/پرایم|پرستیژ|الیت|ایکس\s*۳/)?.[0]||null):(t.match(/(?:تیپ|type)\s*([۲۳۵۶2356])/i)?.[0]||null);
  const needsTrim=found?.[2]==='فیدلیتی'&&!trim;
  const questions=[];
  if(!found)questions.push('مدل دقیق خودرو چیست؟');
  else if(needsTrim)questions.push('فیدلیتی پرایم، پرستیژ یا الیت است؟');
  else if(year===null)questions.push('سال ساخت خودرو چند است؟');
  else if(mileage===null)questions.push('کارکرد خودرو چند کیلومتر است؟');
  return {is_new:isNew,brand:found?.[1]||null,model:found?.[2]||null,year,mileage,
    condition:/بدون رنگ|بی رنگ/.test(t)?'بدون رنگ':null,color,
    transmission:/اتومات/.test(t)?'اتوماتیک':/دستی/.test(t)?'دستی':null,
    body_parts:{},needs_trim:needsTrim,trim,questions,
    generation:/نیو\s*فیس|فیس\s*لیفت/i.test(t)?'نیوفیس':null,transcript:text};
}
function MarketDashboard({result}){
 const[tab,setTab]=useState(result?.vehicle?.mileage===0?'new':'used');
 const stats=tab==='new'?result.new:result.used;
 const urls=new Set(stats?.used_source_urls||[]);
 const usedSources=(result.sources||[]).filter(s=>urls.has(s.url)&&s.accepted);
 const best=stats?.price_average!=null;
 const hist=stats?.histogram||[];
 const highest=Math.max(1,...hist.map(x=>x.count));
 return <section className="intelligence-overview glass" aria-label="داشبورد مدیریتی قیمت">
  <div className="intel-header"><div><span className="eyebrow">هوش بازار · V27</span><h3>خلاصه مدیریتی قیمت</h3><p>فقط شواهد قابل پیگیری؛ امتیاز کیفیت داده، احتمال صحت قیمت نیست.</p></div><div className="intel-tabs" role="group" aria-label="نوع خودرو"><button type="button" onClick={()=>setTab('new')} className={tab==='new'?'active':''}>صفر کیلومتر</button><button type="button" onClick={()=>setTab('used')} className={tab==='used'?'active':''}>کارکرده</button></div></div>
  <div className="intel-kpis">
    <div className="intel-kpi intel-primary"><span>بازه پیشنهادی بازار</span><strong>{best?`${shortMoney(stats.suggested_min)} تا ${shortMoney(stats.suggested_max)}`:'داده کافی نیست'}</strong><small>{!best?'نمونه معتبر کافی یا ترکیب آگهی مناسب وجود ندارد.':'بازه درون نمونه‌های معتبر؛ قیمت قطعی معامله نیست'}</small></div>
    <div className="intel-kpi"><span>میانه قیمت</span><strong>{fmt(stats?.price_median)}</strong><small>قیمت مشاهده‌شده پس از حذف پرت‌ها</small></div>
    <div className="intel-kpi"><span>تعداد شواهد</span><strong>{Number(stats?.listing_count||0).toLocaleString('fa-IR')} آگهی واقعی</strong><small>{Number(stats?.reference_count||0).toLocaleString('fa-IR')} مرجع قیمت · {Number(stats?.domain_count||0).toLocaleString('fa-IR')} سایت مستقل</small></div>
    <div className="intel-kpi"><span>اعتماد به داده‌ها</span><strong>{stats?.sample_count?`${stats.confidence} · ${Number(stats.confidence_score||0).toLocaleString('fa-IR')} از ۱۰۰`:'داده ناکافی'}</strong><small>شاخص ارزیابی کیفیت و پوشش داده، نه احتمال آماری</small></div>
  </div>
  {stats?.sample_count>0&&<p className="intel-context">دامنه مشاهده‌شده: <b>{shortMoney(stats.price_min)} تا {shortMoney(stats.price_max)}</b> · {stats.sample_count.toLocaleString('fa-IR')} شاهد پس از حذف موارد پرت · {Number(stats.outliers_removed||0).toLocaleString('fa-IR')} قیمت پرت کنار گذاشته شد</p>}
  <div className="intel-evidence-grid">
   <div className="intel-table-wrap"><h4>جدول شواهد استفاده‌شده</h4>{usedSources.length?<div className="intel-scroll"><table className="intel-source-table"><thead><tr><th>منبع</th><th>نوع شاهد</th><th>قیمت (تومان)</th><th>اعتبار</th></tr></thead><tbody>{usedSources.map((x,i)=><tr key={x.url+i}><td><a href={x.url} target="_blank" rel="noopener noreferrer">{x.category||x.domain} ↗</a></td><td>{x.evidence_tier|| (x.kind==='listing'?'آگهی':'مرجع')}</td><td>{Number(x.price||0).toLocaleString('fa-IR')}</td><td>{Number(x.quality_score||0).toLocaleString('fa-IR')}/۱۰۰</td></tr>)}</tbody></table></div>:<div className="intel-blank">شاهد معتبری برای این گروه پیدا نشد.</div>}</div>
   <div className="intel-chart-wrap"><h4>نمودار توزیع قیمت</h4>{hist.length?<div className="intel-bars" role="img" aria-label="توزیع قیمت‌های پذیرفته‌شده">{hist.map((bin,i)=><div className="intel-bar-col" key={i} title={`${shortMoney(bin.min)} تا ${shortMoney(bin.max)}: ${bin.count} شاهد`}><span>{bin.count.toLocaleString('fa-IR')}</span><div className="intel-bar" style={{height:`${Math.max(8,bin.count/highest*100)}%`}}/><small>{new Intl.NumberFormat('fa-IR',{maximumFractionDigits:1}).format(bin.min/1e9)}</small></div>)}</div>:<div className="intel-blank">نمودار در صورت وجود شواهد معتبر نمایش داده می‌شود.</div>}<small className="intel-footnote">قیمت روی محور افقی: میلیارد تومان · هر ستون تعداد شواهد آن بازه است.</small></div>
  </div>
  <p className="intel-method">{stats?.pricing_note||'منبع قیمت تأییدشده وجود ندارد.'}</p>
 </section>
}

function App(){const[token,setToken]=useState(sessionStorage.getItem('davoodi_token')||'');const[password,setPassword]=useState('');const[showPass,setShowPass]=useState(false);const[query,setQuery]=useState('');const searchInputRef=useRef(null);const lastSearchPayloadRef=useRef(null);const[busy,setBusy]=useState(false);const[error,setError]=useState('');const[result,setResult]=useState(null);const[carPhoto,setCarPhoto]=useState(null);const[brandLogo,setBrandLogo]=useState(null);const[photoNote,setPhotoNote]=useState('');const[logoNote,setLogoNote]=useState('');const[lastQuery,setLastQuery]=useState('');const[progress,setProgress]=useState(0);const[searchStage,setSearchStage]=useState('');const[listening,setListening]=useState(false);const speechRef=useRef(null);const voiceSessionRef=useRef(false);const voiceTextRef=useRef('');const voiceFinalRef=useRef('');const voiceInterimRef=useRef('');const voiceRestartRef=useRef(0);
const[catalogJson,setCatalogJson]=useState('');const[catalogOpen,setCatalogOpen]=useState(false);const[catalogNotice,setCatalogNotice]=useState('');const[entryMode,setEntryMode]=useState('voice');const[parsed,setParsed]=useState(null);const[voiceReview,setVoiceReview]=useState(false);const[voiceTrim,setVoiceTrim]=useState('');const[history,setHistory]=useState([]);const[historyOpen,setHistoryOpen]=useState(false);const[compareIds,setCompareIds]=useState([]);const[compareData,setCompareData]=useState([]);const[details,setDetails]=useState(false);const[mileage,setMileage]=useState('');const[condition,setCondition]=useState('نامشخص');const[transmission,setTransmission]=useState('');const[bodyParts,setBodyParts]=useState({});const[carColor,setCarColor]=useState('');const[otherColor,setOtherColor]=useState('');const[city,setCity]=useState('');const[includeOptional,setIncludeOptional]=useState(false);const[selectedBodyPart,setSelectedBodyPart]=useState('کاپوت');
const bodyDescription=()=>Object.entries(bodyParts).filter(([,v])=>v&&v!=='سالم').map(([part,status])=>part+' '+status).join('، ');
const effectiveCondition=()=>[bodyDescription()?'':(condition==='بدون رنگ'?'':condition),bodyDescription()].filter(Boolean).join('؛ ')||'نامشخص';
const effectiveColor=()=>carColor==='سایر'?otherColor.trim():carColor;
const headers={'Content-Type':'application/json',Authorization:'Bearer '+token};
async function loadHistory(){if(!token)return;try{const r=await fetch('/api/history',{headers});if(r.ok){const d=await safeJson(r);setHistory(d.items||[])}}catch{}}
useEffect(()=>{if(token)loadHistory()},[token]);
async function openHistory(id){try{setError('');const r=await fetch('/api/history/'+id,{headers});const d=await safeJson(r);if(!r.ok)throw Error(d.detail||'خطا در دریافت گزارش');setResult(d);setLastQuery(d.query||'گزارش قبلی');setQuery(d.query||'');setHistoryOpen(false)}catch(e){setError(e.message)}}
async function compareSelected(){if(compareIds.length<2)return;try{const r=await fetch('/api/compare',{method:'POST',headers,body:JSON.stringify({ids:compareIds})});const d=await safeJson(r);if(!r.ok)throw Error(d.detail||'خطا در مقایسه');setCompareData(d.items||[])}catch(e){setError(e.message)}}
useEffect(()=>{let cancelled=false;let photoObjectUrl=null;setCarPhoto(null);setPhotoNote('');if(!result||!lastQuery||!token)return;const ctrl=new AbortController();fetch('/api/car-image?query='+encodeURIComponent(lastQuery),{headers:{Authorization:'Bearer '+token},signal:ctrl.signal}).then(r=>r.ok?r.json():null).then(d=>{if(!cancelled){if(d?.image_url){fetch(d.image_url,{headers:{Authorization:'Bearer '+token},signal:ctrl.signal}).then(r=>{if(!r.ok)throw new Error('image');return r.blob()}).then(blob=>{if(!cancelled){photoObjectUrl=URL.createObjectURL(blob);setCarPhoto({...d,image_url:photoObjectUrl})}}).catch(()=>{if(!cancelled)setPhotoNote('خطا در دریافت عکس داخلی')})}else setPhotoNote(d?.note||'عکس خودرو یافت نشد')}}).catch(e=>{if(!cancelled&&e?.name!=='AbortError')setPhotoNote('خطا در ارتباط با سرویس عکس')});return()=>{cancelled=true;ctrl.abort();if(photoObjectUrl)URL.revokeObjectURL(photoObjectUrl)}},[result,lastQuery,token]);
useEffect(()=>{let cancelled=false;setBrandLogo(null);setLogoNote('');if(!result||!lastQuery||!token)return;const ctrl=new AbortController();fetch('/api/brand-logo?query='+encodeURIComponent(lastQuery),{headers:{Authorization:'Bearer '+token},signal:ctrl.signal}).then(r=>r.ok?safeJson(r):null).then(d=>{if(!cancelled){if(d?.logo_url)setBrandLogo(d);else setLogoNote(d?.note||'لوگوی برند یافت نشد')}}).catch(e=>{if(!cancelled&&e?.name!=='AbortError')setLogoNote('خطا در ارتباط با سرویس لوگو')});return()=>{cancelled=true;ctrl.abort()}},[result,lastQuery,token]);
useEffect(()=>{if(!result)return;const handle=setTimeout(()=>document.getElementById('price-results')?.scrollIntoView({behavior:'smooth',block:'start'}),100);return()=>clearTimeout(handle)},[result]);
function shareReport(){if(!result)return;const lines=[`گزارش داودی کار | ${lastQuery}`,`قیمت صفر: ${fmt(result.new?.price_average)}`,`قیمت کارکرده: ${fmt(result.used?.price_average)}`,`زمان بررسی: ${new Date(result.checked_at*1000).toLocaleString('fa-IR')}`,'منابع:',...(result.sources||[]).slice(0,6).map(x=>x.url),'این ارقام تخمینی هستند و قیمت قطعی معامله نیستند.'].filter(Boolean);const txt=lines.join('\n');if(navigator.share){navigator.share({title:'گزارش داودی کار',text:txt}).catch(()=>{})}else{navigator.clipboard?.writeText(txt).then(()=>alert('گزارش کپی شد؛ می‌توانید در واتساپ ارسال کنید.')).catch(()=>{const blob=new Blob([txt],{type:'text/plain;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='davoodi-report.txt';a.click();URL.revokeObjectURL(a.href)})}}


async function login(e){e.preventDefault();setBusy(true);setError('');try{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password})});const d=await safeJson(r);if(!r.ok)throw Error(d.detail||'ورود ناموفق');sessionStorage.setItem('davoodi_token',d.token);setToken(d.token);setPassword('')}catch(e){setError(e.message)}finally{setBusy(false)}}
async function search(e,custom,voiceData,forceRefresh=false){
 e?.preventDefault();
 const term=(custom||query).trim();
 if(!term){setError('نام و مدل خودرو را بنویسید.');searchInputRef.current?.focus();return;}
 let payload;
 if(forceRefresh && lastSearchPayloadRef.current && lastSearchPayloadRef.current.query===term){
   payload={...lastSearchPayloadRef.current,refresh:true};
 }else{
   const advanced=entryMode==='manual' && details;
   payload={query:term,
     mileage:voiceData?.is_new?0:(voiceData?.mileage??(advanced&&mileage!==''?Number(mileage):null)),
     condition:voiceData?.condition||(advanced&&bodyDescription()?effectiveCondition():advanced&&condition==='بدون رنگ'?'بدون رنگ':null),
     color:voiceData?.color||(advanced?effectiveColor():null),
     transmission:voiceData?.transmission||(advanced?transmission:null),
     brand:voiceData?.brand||null,model:voiceData?.model||null,year:voiceData?.year||null,
     trim:voiceData?.trim||null,city:advanced?city||null:null,refresh:forceRefresh};
 }
 setQuery(term);setLastQuery(term);setBusy(true);setProgress(0);setSearchStage('در صف جست‌وجو');setError('');setResult(null);
 const requestId=(window.crypto?.randomUUID?.()||('r'+Date.now()+'-'+Math.random().toString(36).slice(2)));
 payload={...payload,request_id:requestId};
 let poll=null;
 try{
   poll=window.setInterval(async()=>{try{const status=await fetch('/api/search-progress/'+encodeURIComponent(requestId),{headers:{Authorization:'Bearer '+token}});if(!status.ok)return;const p=await safeJson(status);setSearchStage([p.stage,p.site].filter(Boolean).join(' · '));if(p.total>0)setProgress(Math.min(95,Math.round(p.done/p.total*90)));}catch{}},900);
   const r=await fetch('/api/search',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(payload)});
   const d=await safeJson(r);
   if(r.status===401){sessionStorage.removeItem('davoodi_token');setToken('');throw Error('نشست شما منقضی شده است. دوباره وارد شوید.');}
   if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:'استعلام انجام نشد؛ مشخصات را بررسی کنید.');
   lastSearchPayloadRef.current={...payload,refresh:false};
   setProgress(100);setResult(d);loadHistory();
 }catch(err){setError(err.message||'اتصال برقرار نشد. دوباره تلاش کنید.');}
 finally{if(poll)window.clearInterval(poll);setBusy(false);setSearchStage('')}
}
async function reviewVoice(text){const transcript=(text||'').trim();setQuery(transcript);setError('');setParsed(null);setVoiceReview(false);if(!transcript){setError('متنی از میکروفن دریافت نشد. دوباره صحبت کنید.');return}let d;try{const r=await fetch('/api/parse-voice',{method:'POST',headers,body:JSON.stringify({text:transcript})});d=await safeJson(r);if(!r.ok)throw Error(d.detail||'خطا در تشخیص مشخصات')}catch(e){d=localVoiceParse(transcript);setError('سرویس تحلیل گفتار در دسترس نیست؛ تشخیص اولیه روی دستگاه انجام شد. مشخصات را بررسی کنید. '+e.message)}if(d.year!=null&&d.mileage!=null&&Number(d.year)===Number(d.mileage)&&!/(?:مدل|سال|ساخت)\s*[۰-۹٠-٩0-9]{2,4}/.test(transcript)){d={...d,year:null};}setParsed(d);setVoiceReview(true);setVoiceTrim(d.trim||'');setMileage(d.mileage!=null?String(d.mileage):'');setCondition(d.condition||'نامشخص');setBodyParts(d.body_parts||{});setCarColor(d.color||'');setTransmission(d.transmission||'');setIncludeOptional(false);if(!d.brand||!d.model)setError('مدل خودرو از گفتار تشخیص داده نشد. متن بالای صفحه را اصلاح کنید و دوباره روی «بررسی متن گفتار» بزنید.')}

async function importCatalog(){try{const parsed=JSON.parse(catalogJson);const items=Array.isArray(parsed)?parsed:parsed.items;if(!Array.isArray(items)||!items.length)throw Error('فایل JSON باید شامل آرایه items باشد');const r=await fetch('/api/catalog/import',{method:'POST',headers,body:JSON.stringify({items})});const d=await safeJson(r);if(!r.ok)throw Error(d.detail||'خطای ذخیره');setCatalogNotice(`${d.imported} ردیف ذخیره شد`)}catch(e){setCatalogNotice('خطا: '+e.message)}}
function submitVoice(){if(!parsed)return;if(!parsed.brand||!parsed.model){setError('برند یا مدل شناسایی نشده است؛ متن را اصلاح و دوباره بررسی کنید.');return;}const trim=voiceTrim?(' '+voiceTrim):'';const normalizedQuery=parsed.is_new?(query.replace(/(^|\s)نو(?=\s|$|[،,.])/g,'$1صفر کیلومتر')+(query.includes('صفر')?'':' صفر کیلومتر')):query;search(null,normalizedQuery+trim,{...parsed,trim:voiceTrim});setVoiceReview(false)}
function finishVoice(){
 voiceSessionRef.current=false;
 const rec=speechRef.current;
 speechRef.current=null;
 if(rec){rec.onend=null;try{rec.stop()}catch{}}
 setListening(false);
 const finalText=[voiceTextRef.current,voiceFinalRef.current,voiceInterimRef.current].filter(Boolean).join(' ').replace(/\\s+/g,' ').trim();
 voiceTextRef.current=finalText;voiceFinalRef.current='';voiceInterimRef.current='';
 if(finalText){
   setQuery(finalText);setVoiceReview(false);
   // Start the same simple model-name search as manual input; no mandatory
   // intermediate confirmation when the server recognizes the model.
   search(null,finalText,null);
 }
 else setError('صدایی شناسایی نشد؛ دوباره تلاش کنید یا مشخصات را بنویسید.');
}
function startVoiceSegment(){
 if(!voiceSessionRef.current)return;
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!Speech){voiceSessionRef.current=false;setListening(false);setError('تشخیص گفتار در این مرورگر فعال نیست؛ Chrome یا Edge را امتحان کنید.');return}
 const rec=new Speech();speechRef.current=rec;
 rec.lang='fa-IR';rec.continuous=true;rec.interimResults=true;
 rec.onstart=()=>{voiceRestartRef.current=0;setListening(true)};
 rec.onresult=e=>{
  let finals='',interim='';
  for(let i=0;i<e.results.length;i++){
   const t=e.results[i][0]?.transcript||'';
   if(e.results[i].isFinal)finals+=(finals?' ':'')+t;
   else interim+=(interim?' ':'')+t;
  }
  voiceFinalRef.current=finals.trim();voiceInterimRef.current=interim.trim();
  setQuery([voiceTextRef.current,finals,interim].filter(Boolean).join(' ').replace(/\\s+/g,' ').trim());
 };
 rec.onerror=e=>{
  if(!voiceSessionRef.current)return;
  if(['not-allowed','service-not-allowed','audio-capture'].includes(e.error)){
   voiceSessionRef.current=false;setListening(false);
   setError(e.error==='audio-capture'?'میکروفن در دسترس نیست.':'اجازه استفاده از میکروفن داده نشده است.');
  }else if(e.error==='network'){
   voiceSessionRef.current=false;setListening(false);
   setError('ارتباط سرویس تشخیص گفتار قطع شد. متن ثبت‌شده حفظ شده است؛ برای ادامه دوباره میکروفن را بزنید.');
  }
 };
 rec.onend=()=>{
  if(voiceFinalRef.current){voiceTextRef.current=[voiceTextRef.current,voiceFinalRef.current].filter(Boolean).join(' ').trim()}
  voiceFinalRef.current='';voiceInterimRef.current='';
  if(!voiceSessionRef.current){setListening(false);return}
  // Browser speech recognition ends on silence; resume while the session remains active.
  voiceRestartRef.current+=1;
  if(voiceRestartRef.current>25){
   voiceSessionRef.current=false;setListening(false);
   setError('مرورگر چند بار تشخیص گفتار را متوقف کرد. متن ثبت‌شده حفظ شده است؛ برای ادامه دوباره میکروفن را بزنید.');
   return;
  }
  try{startVoiceSegment()}catch{voiceSessionRef.current=false;setListening(false);setError('ادامه تشخیص گفتار ممکن نشد.')}
 };
 try{rec.start()}catch{
  voiceSessionRef.current=false;setListening(false);
  setError('امکان فعال‌کردن میکروفن وجود ندارد.');
 }
}
function voice(){
 if(voiceSessionRef.current){finishVoice();return}
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!Speech){setEntryMode('manual');setDetails(true);setError('تشخیص گفتار در این مرورگر فعال نیست. مشخصات خودرو را دستی وارد کنید.');searchInputRef.current?.focus();return}
 setError('');setVoiceReview(false);setParsed(null);
 voiceTextRef.current='';voiceFinalRef.current='';voiceInterimRef.current='';
 voiceRestartRef.current=0;setQuery('');
 voiceSessionRef.current=true;setListening(true);startVoiceSegment();
}
useEffect(()=>()=>{voiceSessionRef.current=false;try{speechRef.current?.abort()}catch{}},[]);
async function browserCheck(){
 try{
  const response=await fetch('/api/browser-check',{headers});
  const data=await safeJson(response);
  window.alert(response.ok?'مرورگر Chromium و اجرای JavaScript در سرور سالم است. این تست به معنی دسترسی به همهٔ سایت‌ها نیست.':
    'مرورگر سرور خطا دارد: '+(data.detail||('HTTP '+response.status)));
 }catch(e){window.alert('آزمون مرورگر انجام نشد: '+String(e?.message||e))}
}
function newCar(startMic=false){
 voiceSessionRef.current=false;
 if(speechRef.current){speechRef.current.onend=null;try{speechRef.current.abort()}catch{}}
 speechRef.current=null;voiceTextRef.current='';voiceFinalRef.current='';voiceInterimRef.current='';voiceRestartRef.current=0;
 setListening(false);setQuery('');setResult(null);setCarPhoto(null);setBrandLogo(null);setLastQuery('');
 setError('');setParsed(null);setVoiceReview(false);setVoiceTrim('');setDetails(false);
 setMileage('');setCondition('نامشخص');setTransmission('');setBodyParts({});setCarColor('');setOtherColor('');setIncludeOptional(false);
 lastSearchPayloadRef.current=null;setHistoryOpen(false);setCompareIds([]);setCompareData([]);setProgress(0);
 document.getElementById('search-car')?.scrollIntoView({behavior:'smooth',block:'start'});
 if(startMic){voice()}else{searchInputRef.current?.focus()}
}
function logout(){sessionStorage.removeItem('davoodi_token');setToken('');setResult(null);setHistory([]);setCompareData([]);setError('')}
return <div className="app"><div className="ambient ambient-one"/><div className="ambient ambient-two"/><div className="shell"><header className="topbar"><div className="brand"><div className="brandmark official-brandmark" aria-label="لوگوی رسمی داودی کارز"><img src={davoudiLogo} alt="Davoudi Cars" /></div><div className="brandcopy"><strong>DAVOUDI <span>CAR</span></strong><small>سامانه اختصاصی نمایشگاه اتومبیل داودی</small></div></div><div className="header-actions">{token&&<><span className="secure-tag"><span className="live-dot"/> دسترسی خصوصی</span><button className="exit-btn" onClick={logout} title="خروج از حساب"><LogOut size={17}/><span>خروج</span></button></>}</div></header>
<main>{!token?<section className="auth-layout"><div className="auth-intro"><span className="overline"><Sparkles size={15}/> هوشمندتر تصمیم بگیرید</span><h1>بازار خودرو،<br/><span className="gold-text">شفاف‌تر از همیشه.</span></h1><p>دسترسی سریع به تحلیل قیمت‌ها، منابع بازار و اطلاعات مورد نیاز برای تصمیم‌گیری دقیق‌تر.</p><div className="auth-feature"><ShieldCheck size={18}/><span>دسترسی اختصاصی کارکنان نمایشگاه داودی</span></div></div><section className="auth-card glass"><div className="auth-icon"><LockKeyhole size={23}/></div><span className="eyebrow">ورود امن</span><h2>خوش آمدید</h2><p>برای ورود به داشبورد، رمز عبور مدیریت را وارد کنید.</p><form onSubmit={login}><label htmlFor="pass">رمز عبور</label><div className="password-wrap"><input id="pass" type={showPass?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password" required placeholder="رمز عبور خود را وارد کنید"/><button type="button" className="eye-btn" onClick={()=>setShowPass(x=>!x)} aria-label={showPass?'پنهان کردن رمز':'نمایش رمز'}>{showPass?<EyeOff size={18}/>:<Eye size={18}/>}</button></div><button className="btn-primary auth-submit" disabled={busy}>{busy?<LoaderCircle className="spin" size={19}/>:<>ورود به داشبورد <ArrowLeft size={18}/></>}</button></form><div className="auth-foot"><ShieldCheck size={15}/> اتصال امن · مخصوص کارکنان</div></section></section>:<><section className="hero" id="search-car"><div className="mobile-step"><span>۱</span> نام خودرو را بگویید یا بنویسید <span className="mobile-step-arrow">↓</span></div><div className="hero-top"><span className="overline"><span className="live-dot"/> استعلام قیمت خودرو</span><span className="hero-date"><Clock3 size={15}/> تحلیل مبتنی بر منابع آنلاین</span></div><h1>فقط نام خودرو را بگویید،<br/><span className="gold-text">بازه قیمت را ببینید</span></h1><p className="hero-sub">{entryMode==='manual'?'مثلاً «فیدلیتی» یا «پژو ۲۰۷». سال و کارکرد اختیاری‌اند.':'نام خودرو را بگویید، «اتمام» را بزنید و نتیجه را ببینید.'}</p><div className="entry-mode-switch" role="group" aria-label="روش ورود مشخصات"><button type="button" className={entryMode==='manual'?'selected':''} onClick={()=>{if(listening)finishVoice();setEntryMode('manual');setVoiceReview(false);setDetails(true);searchInputRef.current?.focus()}}><Search size={17}/> ورود دستی</button><button type="button" className={entryMode==='voice'?'selected':''} onClick={()=>{setEntryMode('voice');setDetails(false)}}><Mic size={17}/> ورود با صدا</button></div><form className="search-panel glass" onSubmit={search}><div className="search-input-row"><div className="search-icon"><Search size={22}/></div><input ref={searchInputRef} aria-label="نام خودرو" value={query} onChange={e=>setQuery(e.target.value)} placeholder={entryMode==='manual'?'فقط نام خودرو؛ مثلاً فیدلیتی یا پژو ۲۰۷':'نام خودرو را بگویید؛ مثلاً سانتافه…'} maxLength={140} required disabled={busy}/>{entryMode==='voice'&&<button type="button" className={"voice-btn "+(listening?"voice-active":"")} onClick={voice} aria-label={listening?"اتمام صحبت و تکمیل فرم":"شروع ضبط صدای خودرو"} title={listening?"اتمام":"شروع صحبت"}>{listening?<AudioLines size={20}/>:<Mic size={20}/>}</button>}{entryMode==='voice'&&<button type="button" className="voice-finish-btn" disabled={!listening} onClick={finishVoice}>اتمام</button>}<button className="btn-primary search-btn" aria-label="نمایش قیمت خودرو" disabled={busy||!query.trim()}>{busy?<><LoaderCircle size={18} className="spin"/> در حال جستجو</>:<>استعلام قیمت <ArrowLeft size={18}/></>}</button></div>{busy&&<div className="progress-track" role="progressbar" aria-label="پیشرفت بررسی منابع" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}><div style={{width:(progress||3)+'%'}}/></div>}</form>{error&&!result&&<div className="search-error" role="alert"><Info size={18}/><span>{error}</span></div>}<div className="quick-examples" aria-label="نمونه‌های جستجوی خودرو"><span>نمونه جستجو:</span>{['سانتافه نیوفیس ۲۰۲۵ صفر کیلومتر','فیدلیتی پرایم ۱۴۰۳ کارکرد ۵۰ هزار کیلومتر','پژو ۲۰۷ اتوماتیک مدل ۱۴۰۱'].map(example=><button key={example} type="button" disabled={busy} onClick={()=>{if(listening)finishVoice();setEntryMode('manual');setVoiceReview(false);setQuery(example);searchInputRef.current?.focus()}}>{example}</button>)}</div><div className="quick-actions"><button type="button" className="new-car-action" disabled={busy} onClick={()=>newCar(entryMode==='voice')}><RotateCcw size={19}/> خودروی بعدی</button><button type="button" onClick={()=>setDetails(x=>!x)}><SlidersHorizontal size={16}/> {details?'بستن مشخصات تکمیلی':'مشخصات بیشتر'}</button><button type="button" onClick={()=>{setHistoryOpen(x=>!x);loadHistory()}}><History size={16}/> تاریخچه استعلام‌ها</button></div>{details&&<div className="advanced-fields glass"><label>کارکرد (کیلومتر)<input inputMode="numeric" type="number" min="0" max="2000000" placeholder="مثلاً 45000" value={mileage} onChange={e=>setMileage(e.target.value)}/></label><label>وضعیت بدنه (برای قیمت دقیق کارکرده)<select value={condition} onChange={e=>setCondition(e.target.value)}><option value="نامشخص">نامشخص (گفته نشده)</option><option value="بدون رنگ">بدون رنگ</option><option value="یک گلگیر رنگ‌شده">یک گلگیر رنگ‌شده</option><option value="یک گلگیر تعویض‌شده">یک گلگیر تعویض‌شده</option><option value="یک گلگیر ضربه‌خورده بدون رنگ">یک گلگیر ضربه‌خورده بدون رنگ</option><option value="یک درب رنگ‌شده">یک درب رنگ‌شده</option><option value="چند قطعه رنگ‌شده">چند قطعه رنگ‌شده</option><option value="تصادفی / آسیب سازه‌ای">تصادفی / آسیب سازه‌ای</option></select></label><label>شهر بازار (اختیاری)<input type="text" maxLength={50} placeholder="مثلاً تهران" value={city} onChange={e=>setCity(e.target.value)}/></label><div className="body-picker"><details className="compact-body-details"><summary>وضعیت بدنه خودرو · {Object.keys(bodyParts).length} قطعه مشخص‌شده</summary><div className="compact-body-list"><label className="compact-part"><span>انتخاب قطعه</span><select value={selectedBodyPart} onChange={e=>setSelectedBodyPart(e.target.value)}>{BODY_PARTS.map(part=><option key={part} value={part}>{part}</option>)}</select></label><label className="compact-part"><span>وضعیت قطعه</span><select aria-label={'وضعیت '+selectedBodyPart} value={bodyParts[selectedBodyPart]||''} onChange={e=>setBodyParts(prev=>{const next={...prev};if(e.target.value)next[selectedBodyPart]=e.target.value;else delete next[selectedBodyPart];return next})}><option value="">نامشخص</option><option value="سالم">سالم (تأییدشده)</option><option value="رنگ‌شده">رنگ‌شده</option><option value="تعویض‌شده">تعویض‌شده</option><option value="ضربه بدون رنگ">ضربه بدون رنگ</option></select></label><div className="selected-body-parts">{Object.entries(bodyParts).map(([part,status])=><button type="button" key={part} className="body-part-chip" onClick={()=>setSelectedBodyPart(part)}>{part}: {status}</button>)}</div><button type="button" className="body-reset" onClick={()=>{setBodyParts(Object.fromEntries(BODY_PARTS.map(p=>[p,'سالم'])));setCondition('بدون رنگ')}}>همه قطعات سالم و بدون رنگ هستند</button><button type="button" className="body-reset" onClick={()=>{setBodyParts({});setCondition('نامشخص')}}>پاک‌کردن وضعیت قطعات</button></div></details></div><div className="color-picker compact-color"><label>رنگ خودرو (اختیاری)<select aria-label="رنگ خودرو" value={carColor} onChange={e=>setCarColor(e.target.value)}><option value="">انتخاب نشده</option>{COLORS.map(c=><option key={c} value={c}>{c}</option>)}</select></label>{carColor==='سایر'&&<input aria-label="رنگ دیگر" placeholder="نام رنگ خودرو" value={otherColor} onChange={e=>setOtherColor(e.target.value)}/>}</div><label>گیربکس<select value={transmission} onChange={e=>setTransmission(e.target.value)}><option value="">نامشخص</option><option value="اتوماتیک">اتوماتیک</option><option value="دستی">دستی</option></select></label></div>}{historyOpen&&<section className="history-panel glass"><div className="section-row"><h3><History size={18}/> تاریخچه استعلام‌ها</h3><span>{history.length} گزارش</span></div>{!history.length?<p>هنوز گزارشی ذخیره نشده است.</p>:<div className="history-list">{history.map(h=><div key={h.id} className="history-item"><label><input type="checkbox" checked={compareIds.includes(h.id)} onChange={e=>setCompareIds(a=>e.target.checked?[...a,h.id].slice(-3):a.filter(x=>x!==h.id))} aria-label={'انتخاب برای مقایسه '+h.query}/></label><button onClick={()=>openHistory(h.id)}><strong>{h.query}</strong><small>{new Date(h.checked_at*1000).toLocaleString('fa-IR')} · کارکرده: {fmt(h.used?.price_average)}</small></button></div>)}</div>}<button className="secondary-btn" disabled={compareIds.length<2} onClick={compareSelected}><GitCompareArrows size={16}/> مقایسه {compareIds.length} خودرو</button>{compareData.length>0&&<div className="compare-table">{compareData.map(x=><div key={x.id}><strong>{x.query}</strong><span>صفر: {fmt(x.new?.price_average)}</span><span>کارکرده: {fmt(x.used?.price_average)}</span></div>)}</div>}</section>}{listening&&<div className="voice-status"><span className="live-dot"/> میکروفن روشن است؛ صحبت کنید و سپس «اتمام» را بزنید.</div>}{voiceReview&&<div className="voice-review glass" role="region" aria-label="تأیید مشخصات خودرو"><h3>مشخصات خودرو را تأیید کنید</h3><p>متن شنیده‌شده را بررسی کنید. اگر چیزی نامشخص است، متن بالا را اصلاح و دوباره تحلیل کنید.</p>{parsed&&<><button type="button" className="secondary-btn" onClick={()=>reviewVoice(query)}>بررسی دوباره متن گفتار</button>{parsed.model_suggestion&&<div className="voice-suggestion"><strong>پیشنهاد تشخیص:</strong> احتمالاً {parsed.model_suggestion.brand} / {parsed.model_suggestion.model} <button type="button" className="secondary-btn" onClick={()=>{setParsed(v=>({...v,brand:v.model_suggestion.brand,model:v.model_suggestion.model,model_suggestion:null}));setError('')}}>تأیید مدل پیشنهادی</button></div>}{parsed.recognition_alias&&<p className="voice-alias">نام شنیده‌شده: «{parsed.recognition_alias}»؛ مدل شناسایی‌شده را پیش از استعلام تأیید کنید.</p>}<div className="voice-chips"><span>برند: {parsed.brand||'نامشخص'}</span><span>مدل: {parsed.model||'نامشخص'}</span><span>سال: {parsed.year||'نامشخص'}</span><span>کارکرد: {parsed.is_new?'صفر کیلومتر':(parsed.mileage!=null?parsed.mileage.toLocaleString('fa-IR'):'نامشخص')}</span><span>بدنه: {parsed.condition||'نامشخص'}</span></div>{parsed.questions?.length>0&&<div className="voice-questions"><strong>برای استعلام دقیق‌تر:</strong>{parsed.questions.filter(q=>!(voiceTrim&&q.includes('فیدلیتی'))).map((q,i)=><p key={i}>{q}</p>)}<small>پاسخ‌ها را در متن بالا یا مشخصات تکمیلی وارد کنید و دوباره بررسی کنید.</small></div>}{parsed.needs_trim&&<div className="trim-picker"><strong>{parsed.model==='۲۰۶'?'پژو ۲۰۶ چه تیپی است؟':parsed.model==='فیدلیتی'?'فیدلیتی کدام نسخه است؟':'نوع موتور خودرو را انتخاب کنید'}</strong><div className="trim-buttons">{[['','نمی‌دانم'],...(TRIM_CHOICES[parsed.model]||[]).map(v=>[v,v])].map(([v,label])=><button type="button" key={label} className={voiceTrim===v?"chosen":""} onClick={()=>setVoiceTrim(v)}>{label}</button>)}</div></div>}<div className="voice-chips">{parsed.color&&<span>رنگ: {parsed.color}</span>}{Object.entries(parsed.body_parts||{}).map(([part,status])=><span key={part}>{part}: {status}</span>)}</div><label className="optional-toggle"><input type="checkbox" checked={includeOptional} onChange={e=>{setIncludeOptional(e.target.checked);setDetails(e.target.checked)}}/> می‌خواهم مشخصات گفته‌نشده را تکمیل کنم (اختیاری)</label>{includeOptional&&<p className="voice-warning">فیلدهای تکمیلی بالای همین بخش باز شدند. فقط مواردی را که می‌دانید وارد کنید.</p>}<button className="btn-primary voice-confirm" type="button" disabled={busy||!parsed.brand||!parsed.model} onClick={submitVoice}>تأیید و استعلام قیمت <ArrowLeft size={18}/></button></>}<button className="secondary-btn" type="button" onClick={()=>{setVoiceReview(false);setParsed(null)}}>بستن</button></div>}</section>{busy&&<section className="searching glass" aria-live="polite"><div className="searching-symbol"><ChartNoAxesCombined size={26}/></div><div><h3>در حال بررسی منابع بازار...</h3><p>{searchStage||'در انتظار پاسخ منابع بازار...'}</p></div><LoaderCircle className="spin" size={24}/></section>}{result&&<section className="results" id="price-results" key={lastQuery}>
<QuickVerdict result={result} onRefresh={()=>search(null,lastQuery,null,true)} onEdit={()=>{document.getElementById('search-car')?.scrollIntoView({behavior:'smooth'});searchInputRef.current?.focus()}} onCheckBrowser={browserCheck}/>
<details className="deep-report" id="full-market-report"><summary>مشاهده گزارش کامل، جدول آگهی‌ها و نمودار قیمت</summary>
<div className="results-heading"><div><span className="eyebrow">گزارش قیمت خودرو · منابع آنلاین</span><h2>{lastQuery}</h2><p>برآورد براساس آگهی‌های مرتبط و قابل پیگیری؛ قیمت قطعی معامله نیست.</p>{result.vehicle?.model&&<div className="detected-vehicle" aria-live="polite">مدل تشخیص‌داده‌شده: <strong>{[result.vehicle.brand,result.vehicle.model,result.vehicle.trim,result.vehicle.year].filter(Boolean).join(' · ')}</strong></div>}{result.cached&&<span className="cache-pill"><Clock3 size={13}/> {result.stale?"آخرین نتیجه ذخیره‌شده":"نتیجه ذخیره‌شده · کاهش مصرف API"}</span>}</div><button className="secondary-btn" onClick={()=>search(null,lastQuery,null,true)} disabled={busy}><RotateCcw size={16}/> استعلام مجدد</button></div>
{!result.model_overview&&<MarketDashboard result={result}/>}
{!(result.new?.price_average||result.used?.price_average||result.model_overview?.groups?.length)&&<div className="search-help glass" role="status"><Info size={20}/><div><strong>برای این مشخصات، برآورد قابل اتکا موجود نیست.</strong><p>تعداد شواهد، وضعیت هر سایت و دلایل حذف در ادامه گزارش آمده‌اند. مشخصات خودرو را دقیق‌تر کنید یا با «استعلام مجدد» بررسی تازه انجام دهید. سیستم قیمت حدسی نمی‌سازد.</p><button type="button" className="secondary-btn" onClick={()=>{document.getElementById('search-car')?.scrollIntoView({behavior:'smooth'});searchInputRef.current?.focus()}}>اصلاح مشخصات خودرو</button></div></div>}<div className="vehicle-overview glass"><div className="vehicle-photo">{carPhoto?.image_url?<img src={carPhoto?.image_url} alt={'تصویر نمونه خودرو '+lastQuery} loading="lazy" onError={e=>{e.currentTarget.style.display='none';e.currentTarget.nextElementSibling.style.display='flex'}}/>:null}<div className="vehicle-photo-empty" style={{display:carPhoto?.image_url?'none':'flex'}}><CarFront size={62}/><span>{photoNote||'در حال بررسی تصویر دقیق خودرو…'}</span></div></div><div className="vehicle-info">{!brandLogo?.logo_url&&logoNote&&<span className="media-note">{logoNote}</span>}{brandLogo?.logo_url&&<div className="brand-logo-wrap"><img className="vehicle-brand-logo" src={brandLogo.logo_url} alt={"لوگوی "+brandLogo.brand} loading="lazy" onError={e=>{e.currentTarget.parentElement.style.display="none"}}/><span>{brandLogo.brand}</span>{brandLogo.source_url&&<a href={brandLogo.source_url} target="_blank" rel="noopener noreferrer">منبع لوگو</a>}</div>}{carPhoto?.image_page&&<a href={carPhoto.image_page} target="_blank" rel="noopener noreferrer" className="photo-credit">تصویر نمونه از Wikimedia Commons · مشاهده منبع</a>}<span className="overline"><span className="live-dot"/> گزارش مقایسه‌ای</span><h3>{lastQuery}</h3><p>قیمت‌ها بر اساس داده‌های قابل استناد در نتایج جستجو هستند؛ قیمت قطعی معامله نیستند.</p><div className="vehicle-tags"><span><ExternalLink size={14}/>{result.sources?.length||0} لینک منبع</span><span><ShieldCheck size={14}/> نمایش قیمت فقط با شواهد</span></div></div></div>
<div className="comparison-title"><h3>مقایسه قیمت بازار</h3><span>تمام مبالغ به تومان</span></div>
<div className="price-compare"><article className="price-panel price-new"><div className="price-head"><span className="price-icon"><Sparkles size={20}/></span><div><h3>خودروی صفر کیلومتر</h3><small>بدون کارکرد · در صورت وجود در بازار</small></div><span className="price-pill">صفر</span></div><div className="price-main">{priceHeadline(result.new)}</div><div className="price-range"><div><span>حداقل</span><strong>{fmt(result.new?.price_min)}</strong></div><div><span>حداکثر</span><strong>{fmt(result.new?.price_max)}</strong></div></div><div className="price-bottom"><CheckCircle2 size={16}/>{result.new?.source_count||0} منبع استفاده‌شده در تحلیل</div></article><article className="price-panel price-used"><div className="price-head"><span className="price-icon"><Gauge size={20}/></span><div><h3>خودروی کارکرده</h3><small>با در نظر گرفتن کارکرد و آسیب بدنه</small></div><span className="price-pill">کارکرده</span></div><div className="price-main">{priceHeadline(result.used)}</div><div className="price-range"><div><span>حداقل</span><strong>{fmt(result.used?.price_min)}</strong></div><div><span>حداکثر</span><strong>{fmt(result.used?.price_max)}</strong></div></div><div className="price-bottom"><CheckCircle2 size={16}/>{result.used?.source_count||0} منبع استفاده‌شده در تحلیل</div></article></div>
<section className="report-actions"><button className="secondary-btn" onClick={shareReport}><Share2 size={17}/> ارسال گزارش</button><button className="secondary-btn" onClick={()=>window.print()}><Download size={17}/> چاپ / PDF</button></section>{result.diagnostics&&<section className="glass market-diagnostics"><div><strong>{result.diagnostics.found||0}</strong><span>نتیجه خام بررسی شد</span></div><div><strong>{result.diagnostics.accepted||0}</strong><span>شاهد معتبر</span></div><div><strong>{result.diagnostics.rejected||0}</strong><span>نتیجه حذف شد</span></div><div><strong>{result.diagnostics.articles_removed||0}</strong><span>مقاله/صفحه نامعتبر</span></div><div><strong>{result.used?.sample_count||0}</strong><span>نمونه کارکرده در محاسبه</span></div><div><strong>{result.used?.confidence||'—'}</strong><span>اطمینان برآورد</span></div></section>}{result.diagnostics?.reasons&&Object.keys(result.diagnostics.reasons).length>0&&<section className="glass rejection-summary"><strong>چرا بعضی نتایج وارد قیمت نشدند؟</strong>{Object.entries(result.diagnostics.reasons).map(([reason,count])=><span key={reason}>{reason}: {count}</span>)}</section>}<div className="detail-grid"><article className="detail-card glass"><div className="detail-heading"><div className="detail-icon"><Sparkles size={19}/></div><div><h3>خلاصه بازار</h3><span>نکات مهم برای خرید و فروش</span></div></div><p className="summary-text">{result.summary||'اطلاعات کافی برای تحلیل موجود نیست.'}</p>{result.warnings?.length>0&&<div className="warnings"><div className="warning-title"><Info size={16}/> نکات احتیاطی</div>{result.warnings.map((x,i)=><p key={i}>{x}</p>)}</div>}</article><article className="detail-card glass"><div className="detail-heading"><div className="detail-icon"><ExternalLink size={19}/></div><div><h3>سایت‌های منبع</h3><span>برای مشاهده آگهی یا قیمت، روی هر سایت بزنید</span></div></div>{result.site_status?.length>0&&<section className="glass-card" style={{padding:16,marginTop:16}}><h3>وضعیت بررسی منابع</h3><div style={{display:'flex',flexWrap:'wrap',gap:8,marginTop:10}}>{result.site_status.map((site,i)=><span key={i} title={[site.domain,site.detail].filter(Boolean).join(' — ')} style={{padding:'6px 10px',borderRadius:12,border:'1px solid rgba(128,128,128,.25)',fontSize:12}}>{site.name} · {site.status==='evidence'?'شاهد معتبر':site.status==='connector'?'اتصال مستقیم':site.status==='searched'?'جستجوی هدفمند':site.status==='cached'?'کش':site.status==='no_results'?'بدون نتیجه':site.status==='rate_limited'?'محدودیت ۴۲۹':site.status==='connector_error'?'خطای اتصال مستقیم':site.status==='not_checked'?'بررسی نشد':site.status==='not_configured'?'کلید جست‌وجو تنظیم نیست':'خطا'} · {site.raw_count??site.count??0} خام · {site.accepted_count||0} معتبر</span>)}</div></section>}{result.sources?.length?<div className="sources">{result.sources.map((s,i)=><a key={i} href={s.url} target="_blank" rel="noopener noreferrer"><span className="source-domain">{s.domain||'منبع وب'}</span><span className="source-title">{s.title||s.url}</span>{s.price&&<small className="source-evidence">قیمت استخراج‌شده: {fmt(s.price)} · تطابق {Math.round(s.relevance||0)}٪</small>}{s.rejection_reason&&<small className="source-rejected">حذف از تحلیل: {s.rejection_reason}</small>}{result.verified_source_urls?.includes(s.url)&&<span className="source-used" title="استفاده‌شده در تحلیل"><Check size={13}/> تحلیل</span>}<ArrowUpLeft size={18}/></a>)}</div>:<div className="empty-sources"><Info size={20}/><p>منبعی پیدا نشد.</p></div>}</article></div><div className="disclaimer">آخرین بررسی: {result.checked_at?new Date(result.checked_at*1000).toLocaleString('fa-IR'):'نامشخص'} · <span> </span><Info size={16}/> قیمت‌های فاقد شواهد کافی نمایش داده نمی‌شوند. تصویر تنها در صورت ارائه توسط نتایج جستجو نمایش داده می‌شود.</div></details></section>}
{!result&&!busy&&<section className="benefits"><div><span className="benefit-icon"><Search size={19}/></span><strong>جستجوی یکپارچه</strong><p>بررسی منابع مختلف بازار</p></div><div><span className="benefit-icon"><Sparkles size={19}/></span><strong>تحلیل قیمت</strong><p>جمع‌بندی قیمت‌های مرتبط</p></div><div><span className="benefit-icon"><CheckCircle2 size={19}/></span><strong>منابع قابل پیگیری</strong><p>نمایش لینک‌های استناد</p></div></section>}</>}{error&&(!token||!!result)&&<div role="alert" className="error"><Info size={18}/>{error}</div>}</main><footer><span>© DAVOUDI CAR</span><span>ابزار پشتیبان تصمیم‌گیری نمایشگاه داودی</span><span>نمایشگاه اتومبیل داودی</span></footer></div></div>}
createRoot(document.getElementById('root')).render(<App/>);