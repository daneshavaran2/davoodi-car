"""DavoodiCar offline-first application."""
